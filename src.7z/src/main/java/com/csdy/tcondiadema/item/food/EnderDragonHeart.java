package com.csdy.tcondiadema.item.food;

public class EnderDragonHeart extends ItemGenericFood {
    public EnderDragonHeart() {
        super(80, 80F, false, true, true, 1);
    }

}
