package com.csdy.tcondiadema.item.sword.sword;

import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;

public class Coal extends SwordItem {
    public Coal(Tier pTier, int pAttackDamageModifier, float pAttackSpeedModifier, Properties pProperties) {
        super(pTier, pAttackDamageModifier, pAttackSpeedModifier, pProperties);
    }
}
