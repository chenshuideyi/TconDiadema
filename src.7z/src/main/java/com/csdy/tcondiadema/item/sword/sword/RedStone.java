package com.csdy.tcondiadema.item.sword.sword;

import net.minecraft.world.item.SwordItem;
import net.minecraft.world.item.Tier;

public class RedStone extends SwordItem {
    public RedStone(Tier pTier, int pAttackDamageModifier, float pAttackSpeedModifier, Properties pProperties) {
        super(pTier, pAttackDamageModifier, pAttackSpeedModifier, pProperties);
    }
}
